"""海信爱家 冰箱 (Hisense AiHome Fridge) 云端 API 客户端。

协议要点（均已实机验证）：
  1. 登录  POST https://portal-account.hismarttv.com/mobile/se/signon
           必须加密：loginName / signature 各自 AES-256-CBC(PKCS7) 后 base64，
           Header 带 appKey=commonweb 与 X-Sign-For = b64(md5(body + PORTAL_APP_SECRET))。
  2. 设备  POST /4.0/iot/devices/list   (withState=true 时状态直接在 devices[].states)
  3. 控制  POST /4.0/iot/devices/execute
           签名 X-Sign-For = b64(md5(body + AIHOME_SIGN_KEY))
           payload.actions = [{"command": ..., "params": {字段: {"value": 数字}}}]
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import time
import uuid
from typing import Any
from urllib.parse import quote

import aiohttp

from .const import (
    AIHOME_APP_VERSION,
    AIHOME_DEVICES,
    AIHOME_EXECUTE,
    AIHOME_FUNCTIONS,
    AIHOME_PLACEHOLDER_DEVICE_ID,
    AIHOME_SIGN_KEY,
    PORTAL_APP_KEY,
    PORTAL_APP_SECRET,
    PORTAL_SIGNON,
    WG_REPORT,
)

_LOGGER = logging.getLogger(__name__)


class HisenseAuthError(Exception):
    """账号或密码错误。"""


class HisenseConnectionError(Exception):
    """网络或接口异常。"""


class HisenseControlError(Exception):
    """指令下发被云端或设备拒绝。"""


def _portal_encrypt(value: str) -> str:
    """按海信 App 的方式加密登录字段：AES-256-CBC + PKCS7 + base64。"""
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

    key = PORTAL_APP_SECRET.encode("ascii")
    iv = PORTAL_APP_SECRET[:16].encode("ascii")
    raw = value.encode("utf-8")
    pad = 16 - (len(raw) % 16)
    padded = raw + bytes([pad]) * pad
    enc = Cipher(algorithms.AES(key), modes.CBC(iv)).encryptor()
    return base64.b64encode(enc.update(padded) + enc.finalize()).decode("ascii")


def _md5_b64(value: str, secret: str) -> str:
    return base64.b64encode(hashlib.md5((value + secret).encode("utf-8")).digest()).decode("ascii")


class HisenseAiHomeClient:
    """无状态 async 客户端；session 由 HA 统一管理。"""

    def __init__(self, session: aiohttp.ClientSession) -> None:
        self._session = session
        # 「使用报告」接口需要的设备标识缓存（serialNumber / comModuleId / homeId）
        self._report_devices: dict[str, dict[str, Any]] = {}

    # ------------------------------------------------------------------ login
    async def async_login(self, username: str, password: str) -> dict[str, Any]:
        """登录海信账号服务，返回 access_token / customer_id。

        ⚠️ 必须使用加密体：明文 loginName 会触发服务端一个不校验密码的旧分支，
        返回固定的假身份（表现为「登录成功但云端 0 设备」）。
        """
        body = json.dumps(
            {
                "loginName": _portal_encrypt(username),
                "signature": _portal_encrypt(password),
                "serverCode": "9501",
                "distributeId": "2001",
                "termType": 2,
            },
            separators=(",", ":"),
            ensure_ascii=False,
        )
        params = {
            "lastUpdateTime": "0",
            "version": "1.0",
            "deviceType": "2",
            "appType": "100",
            "versionCode": "101",
            "adaptertRank": "720",
            "_": str(int(time.time() * 1000)),
        }
        headers = {
            "Content-Type": "application/json; charset=UTF-8",
            "appKey": PORTAL_APP_KEY,
            "X-Sign-For": _md5_b64(body, PORTAL_APP_SECRET),
        }
        try:
            async with self._session.post(
                PORTAL_SIGNON, headers=headers, data=body, params=params, timeout=30
            ) as resp:
                payload = await resp.json(content_type=None)
        except Exception as err:  # noqa: BLE001
            raise HisenseConnectionError(f"登录请求失败: {err}") from err

        data = (payload or {}).get("data") or {}
        if data.get("resultCode") != 0:
            code = data.get("errorCode")
            desc = data.get("errorDesc") or "登录失败"
            if str(code) == "202012":
                raise HisenseAuthError(
                    "海信账号服务拒绝了这组凭据 (errorCode=202012)。请确认："
                    "① 密码是否为「海信爱家」App 当前使用的密码；"
                    "② 该账号是否设置过密码（若平时只用验证码/一键登录，需先在 App 里设置密码）。"
                )
            raise HisenseAuthError(f"{desc} (code={code})")

        info = data.get("tokenInfo") or {}
        token, customer_id = info.get("token"), info.get("customerId")
        if not token or not customer_id:
            raise HisenseAuthError("登录响应缺少 token / customerId")
        return {
            "access_token": str(token),
            "customer_id": str(customer_id),
            "subscriber_id": str(info.get("subscriberId") or ""),
        }

    # ------------------------------------------------------------------ aihome
    def _aihome_headers(self, body: str) -> dict[str, str]:
        return {
            "Content-Type": "application/json; charset=utf-8",
            "Connection": "keep-alive",
            "Accept-Encoding": "gzip",
            "User-Agent": f"JHKMain/{AIHOME_APP_VERSION} (iPhone; iOS 17.0; Scale/3.00)",
            "X-Sign-For": _md5_b64(body, AIHOME_SIGN_KEY),
        }

    async def _aihome_post(
        self,
        url: str,
        access_token: str,
        payload: dict[str, Any],
        *,
        source_name: str | None = None,
        app_version: str = AIHOME_APP_VERSION,
    ) -> dict[str, Any]:
        body_obj: dict[str, Any] = {
            "header": {"messageId": str(uuid.uuid4()), "timestamp": int(time.time() * 1000), "languageId": 0},
            "deviceId": AIHOME_PLACEHOLDER_DEVICE_ID,
            "appVersion": app_version,
            "payload": payload,
            "accessToken": access_token,
            "appType": "2",
        }
        if source_name:
            body_obj["sourceName"] = source_name
        body = json.dumps(body_obj, separators=(",", ":"), ensure_ascii=False)
        try:
            async with self._session.post(
                url, headers=self._aihome_headers(body), data=body, timeout=30
            ) as resp:
                return await resp.json(content_type=None) or {}
        except Exception as err:  # noqa: BLE001
            raise HisenseConnectionError(f"爱家接口请求失败: {err}") from err

    async def async_get_devices(self, access_token: str, customer_id: str) -> list[dict[str, Any]]:
        """列出账号下全部设备（不做品类白名单过滤）。"""
        result = await self._aihome_post(
            AIHOME_DEVICES,
            access_token,
            {
                "withMultiSplit": True,
                "customerId": str(customer_id),
                "withState": True,
                "sourceType": 20,
                "whitelist": 1,
            },
        )
        payload = result.get("payload") or {}
        if payload.get("status") != "SUCCESS":
            raise HisenseConnectionError(
                f"获取设备列表失败: {result.get('errorDesc') or payload.get('status')}"
            )

        devices: list[dict[str, Any]] = []
        for raw in payload.get("devices") or []:
            dev_id = raw.get("deviceId")
            if not dev_id:
                continue
            product = raw.get("product") or {}
            partner = raw.get("partner") or {}
            room = raw.get("room") or {}
            states = raw.get("states") or {}
            devices.append(
                {
                    "device_id": str(dev_id),
                    "category_code": raw.get("categoryCode") or "",
                    "device_name": raw.get("nickname") or raw.get("deviceName")
                    or product.get("name") or str(dev_id),
                    "product_code": product.get("code") or "",
                    "product_name": product.get("name") or "",
                    "room_name": room.get("name") or "",
                    "partner_id": str(partner.get("id") or "1001"),
                    "online": str(states.get("onlineStatus", "1")).strip() != "0",
                    "states": states,
                    "raw": raw,
                    # 下面三项是「使用报告」接口的入参标识
                    "serial_number": str(raw.get("serialNumber") or ""),
                    "com_module_id": str(raw.get("comModuleId") or ""),
                    "home_id": str(raw.get("homeId") or ""),
                }
            )
        return devices

    # ------------------------------------------------------------------ report
    async def async_get_report(
        self, access_token: str, device_id: str, year: int, month: int
    ) -> dict[str, Any]:
        """拉取「使用报告」（开门次数 / 开门时长 / 除菌次数 等）。

        注意：这个接口在**海信智慧家云**（api-wg）上，参数名与爱家云不同：
          deviceid=序列号（serialNumber，非完整 deviceId）、wifiId=comModuleId、homeid
        且**必须 POST + Content-Type: application/json**（GET 返回 405，缺头返回 415）。
        """
        dev = self._report_devices.get(device_id) or {}
        body = {
            "deviceid": dev.get("serial_number") or "",
            "accessToken": access_token,
            "wifiId": dev.get("com_module_id") or "",
            "homeid": dev.get("home_id") or "",
            "yearcode": str(year),
            "monthcode": str(month),
            "type": "month",
            "useJson": True,
        }
        url = f"{WG_REPORT}?accessToken={quote(access_token)}"
        data = json.dumps(body, separators=(",", ":"), ensure_ascii=False)
        headers = {
            "Content-Type": "application/json",
            "User-Agent": f"JHKMain/{AIHOME_APP_VERSION} (iPhone; iOS 17.0; Scale/3.00)",
        }
        try:
            async with self._session.post(url, headers=headers, data=data, timeout=30) as resp:
                payload = await resp.json(content_type=None) or {}
        except Exception as err:  # noqa: BLE001
            raise HisenseConnectionError(f"使用报告请求失败: {err}") from err

        resp_obj = payload.get("response") or {}
        if resp_obj.get("resultCode") != 0:
            raise HisenseConnectionError(
                f"使用报告返回异常: {resp_obj.get('desc') or resp_obj.get('resultCode')}"
            )
        return resp_obj.get("data") or {}

    def set_report_devices(self, devices: list[dict[str, Any]]) -> None:
        """缓存设备标识，供 async_get_report 取 serialNumber / comModuleId / homeId。"""
        self._report_devices = {d["device_id"]: d for d in devices}

    async def async_get_functions(
        self, access_token: str, category_code: str, product_code: str,
        device_id: str, partner_id: str,
    ) -> list[dict[str, Any]]:
        """获取产品功能定义（命令名 / 参数名 / 取值范围）。"""
        result = await self._aihome_post(
            AIHOME_FUNCTIONS,
            access_token,
            {
                "sourceType": 20,
                "products": [{
                    "categoryCode": category_code,
                    "productCode": product_code,
                    "partnerId": partner_id,
                    "deviceId": device_id,
                }],
            },
        )
        payload = result.get("payload") or {}
        products = payload.get("products") or []
        return (products[0].get("functions") or []) if products else []

    # ------------------------------------------------------------------ control
    async def async_execute(
        self,
        access_token: str,
        customer_id: str,
        device_id: str,
        partner_id: str,
        command: str,
        params: dict[str, Any],
        *,
        source_name: str = "smartlifeAppH5",
    ) -> dict[str, Any]:
        """下发一条指令，返回云端回传的 states（失败抛 HisenseControlError）。"""
        result = await self._aihome_post(
            AIHOME_EXECUTE,
            access_token,
            {
                "deviceId": str(device_id),
                "sourceType": "20",
                "exclusionFlag": 1,
                "customerId": str(customer_id),
                "partnerId": str(partner_id),
                "actions": [{"command": command, "params": params}],
            },
            source_name=source_name,
        )
        payload = result.get("payload") or {}
        status = payload.get("status")
        if status == "SUCCESS":
            return payload.get("states") or {}
        raise HisenseControlError(
            f"{payload.get('errorCode') or result.get('errorDesc') or status}"
            f"{(' - ' + payload.get('errorDesc')) if payload.get('errorDesc') else ''}"
        )

    async def async_validate(self, username: str, password: str) -> dict[str, Any]:
        return await self.async_login(username, password)
