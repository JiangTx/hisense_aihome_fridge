"""数据协调器：轮询设备状态 + 自动续期 accessToken。"""

from __future__ import annotations

import logging
import time
from datetime import date, timedelta
from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import ConfigEntryAuthFailed
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .api import HisenseAiHomeClient, HisenseAuthError, HisenseConnectionError
from .const import (
    CATEGORY_FRIDGE,
    CONF_ACCESS_TOKEN,
    CONF_CUSTOMER_ID,
    CONF_PASSWORD,
    CONF_SCAN_INTERVAL,
    CONF_USERNAME,
    DEFAULT_SCAN_INTERVAL,
    DOMAIN,
    REPORT_MIN_INTERVAL,
)

_LOGGER = logging.getLogger(__name__)


class HisenseCoordinator(DataUpdateCoordinator[dict[str, dict[str, Any]]]):
    """拉取账号下所有设备及其 states。

    数据结构：{"devices": {device_id: {...}}, "by_id": {...}}
    为简化实体侧访问，这里直接存两份引用。
    """

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry, client: HisenseAiHomeClient) -> None:
        self.entry = entry
        self.client = client
        options = {**entry.data, **entry.options}
        interval = int(options.get(CONF_SCAN_INTERVAL) or DEFAULT_SCAN_INTERVAL)
        super().__init__(
            hass,
            _LOGGER,
            name=f"{DOMAIN} ({entry.title})",
            update_interval=timedelta(seconds=interval),
        )
        self.devices: dict[str, dict[str, Any]] = {}
        self.functions: dict[str, list[dict[str, Any]]] = {}
        self.reports: dict[str, dict[str, Any]] = {}
        self._functions_loaded: set[str] = set()
        self._report_fetched_at: float = 0.0

    # ------------------------------------------------------------------ props
    @property
    def access_token(self) -> str:
        return self.entry.data.get(CONF_ACCESS_TOKEN, "")

    @property
    def customer_id(self) -> str:
        return self.entry.data.get(CONF_CUSTOMER_ID, "")

    # ------------------------------------------------------------------ token
    async def _async_relogin(self) -> bool:
        """用保存的账号密码重新登录并写回新 token。"""
        username = self.entry.data.get(CONF_USERNAME)
        password = self.entry.data.get(CONF_PASSWORD)
        if not username or not password:
            return False
        auth = await self.client.async_login(username, password)
        new_data = {**self.entry.data, **auth}
        self.hass.config_entries.async_update_entry(self.entry, data=new_data)
        _LOGGER.info("海信爱家 accessToken 已自动续期")
        return True

    # ------------------------------------------------------------------ fetch
    async def _async_update_data(self) -> dict[str, dict[str, Any]]:
        try:
            devices = await self.client.async_get_devices(self.access_token, self.customer_id)
        except HisenseAuthError as err:
            # token 失效 → 尝试自动续期一次
            try:
                if await self._async_relogin():
                    devices = await self.client.async_get_devices(self.access_token, self.customer_id)
                else:
                    raise ConfigEntryAuthFailed(str(err)) from err
            except HisenseAuthError as err2:
                raise ConfigEntryAuthFailed(str(err2)) from err2
            except ConfigEntryAuthFailed:
                raise
            except Exception as err2:  # noqa: BLE001
                raise UpdateFailed(f"续期后仍无法获取设备: {err2}") from err2
        except HisenseConnectionError as err:
            raise UpdateFailed(str(err)) from err

        result: dict[str, dict[str, Any]] = {}
        wanted = set(self.entry.data.get("device_ids") or [])
        for dev in devices:
            if wanted and dev["device_id"] not in wanted:
                continue
            result[dev["device_id"]] = dev
        self.devices = result
        self.client.set_report_devices(list(result.values()))

        # 首次见到某型号时，顺带拉取其功能定义（用于温度范围等）
        for dev in result.values():
            key = dev.get("product_code") or ""
            if not key or key in self._functions_loaded:
                continue
            try:
                self.functions[key] = await self.client.async_get_functions(
                    self.access_token,
                    dev.get("category_code", ""),
                    key,
                    dev["device_id"],
                    dev.get("partner_id", "1001"),
                )
                self._functions_loaded.add(key)
            except Exception as err:  # noqa: BLE001
                _LOGGER.debug("获取 %s 功能定义失败（不影响使用）: %s", key, err)

        await self._async_maybe_fetch_reports(result)
        return result

    # ------------------------------------------------------------------ report
    async def _async_maybe_fetch_reports(self, devices: dict[str, dict[str, Any]]) -> None:
        """低频拉取「使用报告」（开门次数 / 时长 / 除菌次数）。"""
        now = time.time()
        if now - self._report_fetched_at < REPORT_MIN_INTERVAL:
            return
        today = date.today()
        for device_id, dev in devices.items():
            if dev.get("category_code") != CATEGORY_FRIDGE:
                continue
            try:
                self.reports[device_id] = await self.client.async_get_report(
                    self.access_token, device_id, today.year, today.month
                )
            except Exception as err:  # noqa: BLE001
                _LOGGER.debug("获取使用报告失败（不影响使用）: %s", err)
        self._report_fetched_at = now

    # ------------------------------------------------------------------ control
    async def async_send_command(
        self, device_id: str, command: str, params: dict[str, Any], *, source_name: str = "smartlifeAppH5"
    ) -> dict[str, Any]:
        """下发指令，并把回传的 states 立刻写回本地缓存（让 UI 即时更新）。"""
        dev = self.devices.get(device_id) or {}
        try:
            states = await self.client.async_execute(
                self.access_token,
                self.customer_id,
                device_id,
                dev.get("partner_id", "1001"),
                command,
                params,
                source_name=source_name,
            )
        except HisenseAuthError:
            if not await self._async_relogin():
                raise
            states = await self.client.async_execute(
                self.access_token,
                self.customer_id,
                device_id,
                dev.get("partner_id", "1001"),
                command,
                params,
                source_name=source_name,
            )

        if states:
            dev.setdefault("states", {}).update({k: str(v) for k, v in states.items()})
            self.async_set_updated_data(self.devices)
        return states

    async def async_refresh_now(self) -> None:
        await self.async_request_refresh()
