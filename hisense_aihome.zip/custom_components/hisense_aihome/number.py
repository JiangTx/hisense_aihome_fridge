"""温度设定实体（冷藏室 / 冷冻室）。"""

from __future__ import annotations

from homeassistant.components.number import NumberEntity, NumberMode
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import EntityCategory, UnitOfTemperature
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import (
    CATEGORY_FRIDGE,
    CMD_PREFIX,
    CONF_ACCESS_TOKEN,
    FREEZE_TEMP_MAX,
    FREEZE_TEMP_MIN,
    REFRIGERATOR_TEMP_MAX,
    REFRIGERATOR_TEMP_MIN,
)
from .coordinator import HisenseCoordinator
from .entity import HisenseEntity

# (唯一键, 名称, 命令, 参数字段, 状态字段, 最小, 最大)
NUMBER_DEFS = [
    (
        "set_refrigerator",
        "冷藏室设定温度",
        CMD_PREFIX + "SetTemperature.Refrigerator",
        "refrigeratorSetTemperature",
        "refrigeratorSetTemperature",
        REFRIGERATOR_TEMP_MIN,
        REFRIGERATOR_TEMP_MAX,
    ),
    (
        "set_freeze",
        "冷冻室设定温度",
        CMD_PREFIX + "SetTemperature.Freeze",
        "freezeSetTemperature",
        "freezeSetTemperature",
        FREEZE_TEMP_MIN,
        FREEZE_TEMP_MAX,
    ),
]


async def async_setup_entry(
    hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback
) -> None:
    coordinator: HisenseCoordinator = hass.data["hisense_aihome"][entry.entry_id]
    entities = []
    for device_id, dev in coordinator.devices.items():
        if dev.get("category_code") != CATEGORY_FRIDGE:
            continue
        for uid, name, cmd, param, state_key, lo, hi in NUMBER_DEFS:
            entities.append(
                HisenseTempNumber(coordinator, device_id, uid, name, cmd, param, state_key, lo, hi)
            )
    async_add_entities(entities)


class HisenseTempNumber(HisenseEntity, NumberEntity):
    _attr_has_entity_name = True
    _attr_mode = NumberMode.BOX
    _attr_native_unit_of_measurement = UnitOfTemperature.CELSIUS
    _attr_native_step = 1
    _attr_icon = "mdi:thermometer"

    def __init__(self, coordinator, device_id, uid, name, cmd, param, state_key, lo, hi) -> None:
        super().__init__(coordinator, device_id, uid)
        self._attr_name = name
        self._cmd = cmd
        self._param = param
        self._state_key = state_key
        self._attr_native_min_value = float(lo)
        self._attr_native_max_value = float(hi)

    @property
    def native_value(self) -> float | None:
        raw = self._states.get(self._state_key)
        if raw in (None, "", "--"):
            return None
        try:
            return float(raw)
        except (TypeError, ValueError):
            return None

    async def async_set_native_value(self, value: float) -> None:
        await self.coordinator.async_send_command(
            self._device_id, self._cmd, {self._param: {"value": int(value)}}
        )
