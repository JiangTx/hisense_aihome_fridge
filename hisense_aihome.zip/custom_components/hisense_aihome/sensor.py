"""传感器：温度、在线状态、故障汇总。"""

from __future__ import annotations

import re
from typing import Any

from homeassistant.components.sensor import (
    SensorDeviceClass,
    SensorEntity,
    SensorStateClass,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import EntityCategory, UnitOfTemperature
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import (
    CATEGORY_FRIDGE,
    FAULT_KEY_HINTS,
    KEY_FREEZE_REAL,
    KEY_FREEZE_SET,
    KEY_REFRIGERATOR_REAL,
    KEY_REFRIGERATOR_SET,
    KEY_VARIA_DRAWER,
    VARIA_OPTIONS,
)
from .coordinator import HisenseCoordinator
from .entity import HisenseEntity

# (状态字段, 名称, 单位, 设备类, 状态类)
TEMP_SENSORS: list[tuple[str, str, str | None, str | None, str | None]] = [
    (KEY_REFRIGERATOR_REAL, "冷藏室实际温度", UnitOfTemperature.CELSIUS, SensorDeviceClass.TEMPERATURE, SensorStateClass.MEASUREMENT),
    (KEY_FREEZE_REAL, "冷冻室实际温度", UnitOfTemperature.CELSIUS, SensorDeviceClass.TEMPERATURE, SensorStateClass.MEASUREMENT),
    (KEY_REFRIGERATOR_SET, "冷藏室设定温度", UnitOfTemperature.CELSIUS, SensorDeviceClass.TEMPERATURE, None),
    (KEY_FREEZE_SET, "冷冻室设定温度", UnitOfTemperature.CELSIUS, SensorDeviceClass.TEMPERATURE, None),
]


async def async_setup_entry(
    hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback
) -> None:
    coordinator: HisenseCoordinator = hass.data["hisense_aihome"][entry.entry_id]
    entities: list[SensorEntity] = []
    for device_id, dev in coordinator.devices.items():
        if dev.get("category_code") != CATEGORY_FRIDGE:
            continue
        for key, name, unit, dev_cls, state_cls in TEMP_SENSORS:
            entities.append(
                HisenseTempSensor(coordinator, device_id, key, name, unit, dev_cls, state_cls)
            )
        entities.append(HisenseVariaSensor(coordinator, device_id))
        entities.append(HisenseOnlineSensor(coordinator, device_id))
        entities.append(HisenseFaultSensor(coordinator, device_id))
        # ---- 「使用报告」实体 --------------------------------------------------
        # 数据来自海信智慧家云看板接口，由 coordinator 每 3 小时拉一次，
        # 原始字段见 api.HisenseAiHomeClient.async_get_report 与 README「其他可读取数据」。
        #
        # 目前只启用「本月开门次数」这一个实体。
        # 其余指标（开门时长 / 平均时长 / 除菌次数）读取逻辑已全部就绪，
        # 如需显示，取消对应行的注释即可；也可照 _FIELDS 里的映射自行新增。
        entities.append(
            HisenseReportSensor(coordinator, device_id, "door_count", "本月开门次数", "次", "mdi:door-open")
        )
        # entities.append(
        #     HisenseReportSensor(coordinator, device_id, "door_duration", "本月开门时长", "s", "mdi:timer-outline", duration=True)
        # )
        # entities.append(
        #     HisenseReportSensor(coordinator, device_id, "door_avg", "平均开门时长", "s", "mdi:timer-sand")
        # )
        # entities.append(
        #     HisenseReportSensor(coordinator, device_id, "degerm_count", "本月除菌次数", "次", "mdi:shield-check-outline")
        # )
    async_add_entities(entities)


class HisenseTempSensor(HisenseEntity, SensorEntity):
    _attr_has_entity_name = True

    def __init__(self, coordinator, device_id, key, name, unit, dev_cls, state_cls) -> None:
        super().__init__(coordinator, device_id, f"temp_{key}")
        self._key = key
        self._attr_name = name
        self._attr_native_unit_of_measurement = unit
        if dev_cls:
            self._attr_device_class = dev_cls
        if state_cls:
            self._attr_state_class = state_cls

    @property
    def native_value(self) -> float | None:
        raw = self._states.get(self._key)
        if raw in (None, "", "--"):
            return None
        try:
            return float(raw)
        except (TypeError, ValueError):
            return None


class HisenseVariaSensor(HisenseEntity, SensorEntity):
    _attr_name = "变温抽屉"
    _attr_icon = "mdi:drawer"

    def __init__(self, coordinator, device_id) -> None:
        super().__init__(coordinator, device_id, "varia_drawer")

    @property
    def native_value(self) -> str | None:
        raw = self.state_of(KEY_VARIA_DRAWER)
        if raw is None:
            return None
        try:
            return VARIA_OPTIONS.get(int(raw), raw)
        except (TypeError, ValueError):
            return raw


class HisenseOnlineSensor(HisenseEntity, SensorEntity):
    _attr_name = "在线状态"
    _attr_icon = "mdi:wifi"
    _attr_entity_category = EntityCategory.DIAGNOSTIC

    def __init__(self, coordinator, device_id) -> None:
        super().__init__(coordinator, device_id, "online")

    @property
    def native_value(self) -> str:
        return "在线" if self._device.get("online", True) else "离线"


class HisenseFaultSensor(HisenseEntity, SensorEntity):
    """把所有故障/告警位汇总成一个实体：正常 / 具体故障名。"""

    _attr_name = "故障"
    _attr_icon = "mdi:alert-circle-outline"

    def __init__(self, coordinator, device_id) -> None:
        super().__init__(coordinator, device_id, "fault")

    def _active(self) -> dict[str, str]:
        out: dict[str, str] = {}
        for k, v in self._states.items():
            if not any(h.lower() in k.lower() for h in FAULT_KEY_HINTS):
                continue
            sv = str(v)
            if sv in ("0", "--", "", "None"):
                continue
            out[k] = sv
        return out

    @property
    def native_value(self) -> str:
        active = self._active()
        if not active:
            return "正常"
        k, v = next(iter(active.items()))
        return f"{k}={v}" + (f" 等 {len(active)} 项" if len(active) > 1 else "")

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        return {"active_faults": self._active()}


class HisenseReportSensor(HisenseEntity, SensorEntity):
    """「使用报告」指标（开门次数等）。

    数据来自海信智慧家云看板接口（按天更新），协调器每 3 小时拉一次。
    已在 async_setup_entry 中只启用「本月开门次数」，其余见下方注释。

    ======== 该接口可读取的全部字段（备查，2026-10 实测）================
      switchCount        本月开门次数              int
      switchDuration     本月累计开门时长（秒）     int
      switchAvgDuration  平均每次开门时长（秒）     int
      degermCount        本月除菌次数              int
      switchCountDis     分时段开门次数分布         dict  {"8-11":72, ...}
      switchDurationDis  分时段开门时长分布         dict  {"8-11":1088, ...}
      bindDays           设备已绑定天数            int
      titleCode/titlePercent/titlename/titledesc   能耗称号及文案
      switchAvgRank      平均开门时长的全国排名前%  int
      switchCount05Rank  开门次数的排名前%          int
      switchAvgDurYtd    年初至今平均开门时长（秒）  int
      updateTime         数据更新日期              str
      errorList          异常项                    str（空为正常）
      foodDis/foodChart/foodOpRank                 食材相关（部分机型为空）
    ===================================================================
    """

    # uid -> 报告接口原始字段
    _FIELDS = {
        "door_count": "switchCount",
        "door_duration": "switchDuration",
        "door_avg": "switchAvgDuration",
        "degerm_count": "degermCount",
        # 如需更多实体，在此登记后于 async_setup_entry 中追加即可：
        # "door_duration_ytd": "switchAvgDurYtd",
        # "bind_days": "bindDays",
    }

    def __init__(
        self, coordinator, device_id, uid: str, name: str, unit: str, icon: str, *, duration: bool = False
    ) -> None:
        super().__init__(coordinator, device_id, f"report_{uid}")
        self._attr_name = name
        self._attr_native_unit_of_measurement = unit
        self._attr_icon = icon
        self._attr_state_class = SensorStateClass.MEASUREMENT
        self._field = self._FIELDS[uid]
        self._duration = duration

    @property
    def native_value(self) -> float | None:
        raw = self._report.get(self._field)
        if raw in (None, "", "--"):
            return None
        try:
            return float(raw)
        except (TypeError, ValueError):
            return None

    @property
    def available(self) -> bool:
        # 报告接口偶发失败时保持实体可用（显示为未知），不整片置为不可用
        return super().available

    @staticmethod
    def _human(seconds: float) -> str:
        s = int(seconds)
        h, rem = divmod(s, 3600)
        m, sec = divmod(rem, 60)
        if h:
            return f"{h} 小时 {m} 分"
        if m:
            return f"{m} 分 {sec} 秒"
        return f"{sec} 秒"

    @staticmethod
    def _plain_title(raw: Any) -> str | None:
        """titlename 里带 <br>/<span>，转成纯文本再放进属性。"""
        if not raw:
            return None
        text = re.sub(r"<[^>]+>", " ", str(raw))
        return " ".join(text.split()) or None

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        r = self._report
        out: dict[str, Any] = {
            "统计月份": f"{r.get('yearcode')}-{str(r.get('monthcode')).zfill(2)}" if r.get("yearcode") else None,
            "数据更新日": r.get("updateTime"),
            "已绑定天数": r.get("bindDays"),
            "全国排名前百分比": r.get("switchAvgRank"),
            "称号": self._plain_title(r.get("titlename")),
        }
        # 开门时段分布只在「开门次数」实体上暴露一次，避免重复
        if self._field == "switchCount" and r.get("switchCountDis"):
            out["分时段开门次数"] = r["switchCountDis"]
        if self._duration and r.get("switchDuration") is not None:
            try:
                out["可读时长"] = self._human(float(r["switchDuration"]))
            except (TypeError, ValueError):
                pass
        return {k: v for k, v in out.items() if v is not None}
