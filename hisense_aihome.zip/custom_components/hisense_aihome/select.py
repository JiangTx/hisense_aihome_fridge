"""下拉选择实体：工作模式、变温抽屉。"""

from __future__ import annotations

from homeassistant.components.select import SelectEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import (
    CATEGORY_FRIDGE,
    CMD_PREFIX,
    KEY_VARIA_DRAWER,
    KEY_WORK_MODE,
    VARIA_OPTIONS,
    VARIA_REVERSE,
    WORK_MODE_OPTIONS,
    WORK_MODE_REVERSE,
)
from .coordinator import HisenseCoordinator
from .entity import HisenseEntity


async def async_setup_entry(
    hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback
) -> None:
    coordinator: HisenseCoordinator = hass.data["hisense_aihome"][entry.entry_id]
    entities = []
    for device_id, dev in coordinator.devices.items():
        if dev.get("category_code") != CATEGORY_FRIDGE:
            continue
        entities.append(HisenseWorkModeSelect(coordinator, device_id))
        entities.append(HisenseVariaSelect(coordinator, device_id))
    async_add_entities(entities)


class HisenseWorkModeSelect(HisenseEntity, SelectEntity):
    """工作模式：智能 / 速冷 / 一键冰封。"""

    _attr_name = "模式"
    _attr_icon = "mdi:fridge-outline"

    def __init__(self, coordinator, device_id) -> None:
        super().__init__(coordinator, device_id, "work_mode")
        self._attr_options = list(WORK_MODE_OPTIONS.values())

    @property
    def current_option(self) -> str | None:
        raw = self.state_of(KEY_WORK_MODE)
        if raw is None:
            return None
        try:
            return WORK_MODE_OPTIONS.get(int(raw), None)
        except (TypeError, ValueError):
            return None

    async def async_select_option(self, option: str) -> None:
        value = WORK_MODE_REVERSE.get(option)
        if value is None:
            return
        await self.coordinator.async_send_command(
            self._device_id, CMD_PREFIX + "SetModes", {"modes": {"value": value}}
        )


class HisenseVariaSelect(HisenseEntity, SelectEntity):
    """变温抽屉：冰鲜 / 0°保鲜 / 母婴。"""

    _attr_name = "变温抽屉模式"
    _attr_icon = "mdi:drawer"

    def __init__(self, coordinator, device_id) -> None:
        super().__init__(coordinator, device_id, "varia_select")
        self._attr_options = list(VARIA_OPTIONS.values())

    @property
    def current_option(self) -> str | None:
        raw = self.state_of(KEY_VARIA_DRAWER)
        if raw is None:
            return None
        try:
            return VARIA_OPTIONS.get(int(raw), None)
        except (TypeError, ValueError):
            return None

    async def async_select_option(self, option: str) -> None:
        value = VARIA_REVERSE.get(option)
        if value is None:
            return
        await self.coordinator.async_send_command(
            self._device_id,
            CMD_PREFIX + "VariationTemperature",
            {"variationTemperatureDrawer": {"value": value}},
        )
