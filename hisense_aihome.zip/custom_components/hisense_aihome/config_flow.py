"""配置流程：账号密码登录 + 设备多选。

UI 添加集成 → 输入「海信爱家」手机号/密码 → 自动列出账号下设备 → 勾选要接入的设备。
"""

from __future__ import annotations

import logging
from typing import Any

import voluptuous as vol

from homeassistant.config_entries import ConfigEntry, ConfigFlow, OptionsFlow
from homeassistant.core import callback
from homeassistant.data_entry_flow import FlowResult
from homeassistant.helpers import aiohttp_client, config_validation as cv

from .api import HisenseAiHomeClient, HisenseAuthError, HisenseConnectionError
from .const import (
    CONF_ACCESS_TOKEN,
    CONF_CUSTOMER_ID,
    CONF_PASSWORD,
    CONF_SCAN_INTERVAL,
    CONF_USERNAME,
    DEFAULT_SCAN_INTERVAL,
    DOMAIN,
    NAME,
)

_LOGGER = logging.getLogger(__name__)

STEP_USER = vol.Schema(
    {
        vol.Required(CONF_USERNAME): cv.string,
        vol.Required(CONF_PASSWORD): cv.string,
    }
)


class HisenseConfigFlow(ConfigFlow, domain=DOMAIN):
    """首次配置流程。"""

    VERSION = 1

    def __init__(self) -> None:
        self._username: str = ""
        self._password: str = ""
        self._auth: dict[str, Any] = {}
        self._devices: list[dict[str, Any]] = []

    async def async_step_user(self, user_input: dict[str, Any] | None = None) -> FlowResult:
        errors: dict[str, str] = {}
        if user_input is not None:
            self._username = user_input[CONF_USERNAME]
            self._password = user_input[CONF_PASSWORD]
            session = aiohttp_client.async_get_clientsession(self.hass)
            client = HisenseAiHomeClient(session)
            try:
                self._auth = await client.async_login(self._username, self._password)
                self._devices = await client.async_get_devices(
                    self._auth["access_token"], self._auth["customer_id"]
                )
            except HisenseAuthError as err:
                _LOGGER.warning("海信爱家登录失败: %s", err)
                errors["base"] = "invalid_auth"
            except HisenseConnectionError as err:
                _LOGGER.warning("海信爱家连接失败: %s", err)
                errors["base"] = "cannot_connect"
            except Exception:  # noqa: BLE001
                _LOGGER.exception("海信爱家配置出现未知异常")
                errors["base"] = "unknown"
            else:
                if not self._devices:
                    errors["base"] = "no_devices"
                else:
                    return await self.async_step_devices()

        return self.async_show_form(step_id="user", data_schema=STEP_USER, errors=errors)

    async def async_step_devices(self, user_input: dict[str, Any] | None = None) -> FlowResult:
        options = {
            d["device_id"]: f"{d['device_name']}（{d.get('product_name') or d.get('product_code') or '未知型号'}）"
            for d in self._devices
        }
        schema = vol.Schema(
            {
                vol.Required("devices", default=list(options)): cv.multi_select(options),
            }
        )
        if user_input is not None:
            chosen = user_input.get("devices") or []
            if not chosen:
                return self.async_show_form(step_id="devices", data_schema=schema, errors={"base": "no_devices"})
            return self.async_create_entry(
                title=f"{NAME} ({len(chosen)} 台设备)",
                data={
                    CONF_USERNAME: self._username,
                    CONF_PASSWORD: self._password,
                    CONF_ACCESS_TOKEN: self._auth["access_token"],
                    CONF_CUSTOMER_ID: self._auth["customer_id"],
                    "device_ids": chosen,
                },
            )
        return self.async_show_form(step_id="devices", data_schema=schema)

    @staticmethod
    @callback
    def async_get_options_flow(config_entry: ConfigEntry) -> OptionsFlow:
        return HisenseOptionsFlow()


class HisenseOptionsFlow(OptionsFlow):
    """选项：轮询间隔。"""

    async def async_step_init(self, user_input: dict[str, Any] | None = None) -> FlowResult:
        if user_input is not None:
            return self.async_create_entry(title="", data=user_input)
        current = self.config_entry.options.get(CONF_SCAN_INTERVAL, DEFAULT_SCAN_INTERVAL)
        return self.async_show_form(
            step_id="init",
            data_schema=vol.Schema(
                {
                    vol.Optional(CONF_SCAN_INTERVAL, default=current): vol.All(
                        vol.Coerce(int), vol.Range(min=15, max=3600)
                    )
                }
            ),
        )
