"""二进制传感器：开门告警、离线。"""

from __future__ import annotations

from homeassistant.components.binary_sensor import (
    BinarySensorDeviceClass,
    BinarySensorEntity,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import EntityCategory
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import CATEGORY_FRIDGE
from .coordinator import HisenseCoordinator
from .entity import HisenseEntity

# (唯一键, 名称, 状态字段, 设备类)
BINARY_DEFS = [
    ("door_refri", "冷藏室开门告警", "refriOpenDoorAlarm", BinarySensorDeviceClass.DOOR),
    ("door_freeze", "冷冻室开门告警", "freezeOpenDoorAlarm", BinarySensorDeviceClass.DOOR),
    ("door_varia", "变温室开门告警", "variaOpenDoorAlarm", BinarySensorDeviceClass.DOOR),
]


async def async_setup_entry(
    hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback
) -> None:
    coordinator: HisenseCoordinator = hass.data["hisense_aihome"][entry.entry_id]
    entities = []
    for device_id, dev in coordinator.devices.items():
        if dev.get("category_code") != CATEGORY_FRIDGE:
            continue
        for uid, name, state_key, dev_cls in BINARY_DEFS:
            entities.append(HisenseBinary(coordinator, device_id, uid, name, state_key, dev_cls))
    async_add_entities(entities)


class HisenseBinary(HisenseEntity, BinarySensorEntity):
    _attr_has_entity_name = True

    def __init__(self, coordinator, device_id, uid, name, state_key, dev_cls) -> None:
        super().__init__(coordinator, device_id, uid)
        self._attr_name = name
        self._state_key = state_key
        self._attr_device_class = dev_cls

    @property
    def is_on(self) -> bool:
        # 0=正常(关闭), 1=报警(开启)
        return self.state_of(self._state_key, "0") == "1"
