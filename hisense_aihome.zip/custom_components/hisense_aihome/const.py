"""Constants for the Hisense AiHome Fridge (海信爱家 冰箱) integration."""

DOMAIN = "hisense_aihome"
NAME = "海信爱家 冰箱"

CONF_USERNAME = "username"
CONF_PASSWORD = "password"
CONF_ACCESS_TOKEN = "access_token"
CONF_CUSTOMER_ID = "customer_id"
CONF_SCAN_INTERVAL = "scan_interval"

DEFAULT_SCAN_INTERVAL = 60

# --- endpoints -------------------------------------------------------------
PORTAL_SIGNON = "https://portal-account.hismarttv.com/mobile/se/signon"
AIHOME_BASE = "https://iot-aihome.hismarttv.com"
AIHOME_DEVICES = AIHOME_BASE + "/4.0/iot/devices/list"
AIHOME_DETAIL = AIHOME_BASE + "/4.0/iot/devices/detail"
AIHOME_EXECUTE = AIHOME_BASE + "/4.0/iot/devices/execute"
AIHOME_FUNCTIONS = AIHOME_BASE + "/4.0/iot/devices/function/getByProduct"

# 「使用报告」看板（海信智慧家云，走 api-wg），返回开门次数 / 时长 / 除菌次数等
WG_BASE = "https://api-wg.hismarttv.com"
WG_REPORT = WG_BASE + "/agw/dataBoard/getWMReportMonthData"
REPORT_MIN_INTERVAL = 3 * 3600  # 报告按天更新，最多每 3 小时拉一次

PORTAL_APP_KEY = "commonweb"

# ---------------------------------------------------------------------------
# 以下两个常量来自海信官方 App 的客户端协议（随 APK 分发给每个客户端，
# 并非用户凭据）。海信更新 App 后若失效，重新抓包替换即可。
#   PORTAL_APP_SECRET : 登录字段 AES 密钥/IV + 登录请求签名密钥
#   AIHOME_SIGN_KEY   : 爱家接口 X-Sign-For 的签名密钥
# ---------------------------------------------------------------------------
PORTAL_APP_SECRET = "MORZRbkuiWxjp+SM4vR_GxY4pZxLZ6rn"  # noqa: S105
AIHOME_SIGN_KEY = "AOSj8JBr0IpUzv5w+hURR6W4oINsI4o5"    # noqa: S105
AIHOME_APP_VERSION = "7.0.8.12"
AIHOME_PLACEHOLDER_DEVICE_ID = "862fff02fffefff00000fffe53b30aa3fdb331c013166f31a6089802"

CONTROL_SOURCE_NAME = "smartlifeAppH5"
POWER_SOURCE_NAME = "smartlifeApp"
CMD_PREFIX = "connector.device.command."

# --- 品类 ------------------------------------------------------------------
CATEGORY_FRIDGE = "connector.device.type.fridge"

# --- 冰箱状态字段 ----------------------------------------------------------
KEY_REFRIGERATOR_SET = "refrigeratorSetTemperature"
KEY_REFRIGERATOR_REAL = "refrigeratorRealTemperature"
KEY_FREEZE_SET = "freezeSetTemperature"
KEY_FREEZE_REAL = "freezeRealTemperature"
KEY_WORK_MODE = "workMode"
KEY_ONLINE = "onlineStatus"
KEY_VARIA_DRAWER = "variationTemperatureDrawer"
KEY_CLEAR_SWITCH = "clearSwitch"

# 温度取值范围（实测自云端返回的 range 提示）
REFRIGERATOR_TEMP_MIN = 2
REFRIGERATOR_TEMP_MAX = 8
FREEZE_TEMP_MIN = -25
FREEZE_TEMP_MAX = -15

# 工作模式取值
WORK_MODE_OPTIONS = {
    0: "智能",
    3: "速冷",
    7: "一键冰封",
}
WORK_MODE_REVERSE = {v: k for k, v in WORK_MODE_OPTIONS.items()}

# 变温抽屉
VARIA_OPTIONS = {0: "冰鲜", 1: "0°保鲜", 2: "母婴"}
VARIA_REVERSE = {v: k for k, v in VARIA_OPTIONS.items()}

# 模式开关命令表（**当前未使用**，保留备查）
#
# ⚠️ 不要用它来生成独立的 switch 实体。云端 workMode 是单值互斥枚举
#    （0智能 / 3速冷 / 7一键冰封），这三个模式任意时刻只能取其一；
#    实测下发 SetModes.<X> 会把 workMode 置为非法值 "--"。
#    正确做法是走 SetModes 命令（见 select.py 的「模式」下拉）。
MODE_SWITCHES = {
    "smart": ("SetModes.Smart", "smartModeSwitch", "workMode.Smart", "智能模式"),
    "quick_cooling": ("SetModes.QuickCooling", "quickCoolingModeSwitch", "workMode.QuickCooling", "速冷模式"),
    "quick_ice_bound": ("SetModes.QuickIceBound", "quickIceBoundModeSwitch", "workMode.QuickIceBound", "一键冰封"),
}

# 故障/告警字段前缀（正常时多为 "0" 或 "--"）
FAULT_KEY_HINTS = ("Fault", "Alarm", "Error", "Failure", "Clogging", "hydropenia")

# ---------------------------------------------------------------------------
# 其他可读取数据（备查，尚未做成实体）
# ---------------------------------------------------------------------------
# 【A】「使用报告」看板 —— POST https://api-wg.hismarttv.com/agw/dataBoard/getWMReportMonthData
#   入参：deviceid=serialNumber, wifiId=comModuleId, homeid, yearcode, monthcode,
#         type=month|year（仅支持这两种）, useJson=true；accessToken 走 query。
#   ⚠️ 必须 POST + Content-Type: application/json（GET→405，缺头→415）
#   可取字段：
#     switchCount        本月开门次数
#     switchDuration     本月累计开门时长（秒）
#     switchAvgDuration  平均每次开门时长（秒）
#     degermCount        本月除菌次数
#     switchCountDis     分时段开门次数 {"8-11":72, ...}
#     switchDurationDis  分时段开门时长
#     bindDays           已绑定天数
#     titlename/titledesc/titlePercent  能耗称号与文案
#     switchAvgRank      平均开门时长全国排名前%
#     switchCount05Rank  开门次数排名前%
#     switchAvgDurYtd    年初至今平均开门时长
#     updateTime         数据更新日期
#   历史范围：从设备绑定日起全量（本机实测可回溯至 2024-10，共 24 个月）。
#
# 【B】告警看板 —— POST /4.0/iot/databoard/fridge/alarmState/query（爱家云，需签名）
#   返回 payload.alarmStateCodeList（告警码列表，正常为空数组）。
#
# 【C】能耗看板 —— POST /4.0/iot/databoard/fridge/energy/query（爱家云，需签名）
#   返回 payload.recentEnergyInfo.{totalEnergy, saveEnergy}。
#   ⚠️ 本机型固件未采集电量，恒为 "0"，不可用。
#
# 【D】设备详情里的非 states 信息（/4.0/iot/devices/detail，已由 api 解析）
#   deviceInfo.{hwVersion, swVersion}  固件/硬件版本
#   product.{code, name, featureCode, smallIcon, largeIcon}
#   bindDate / reportTime / offlineTime / homeId / room.name / labels
#   originalState                      一串逗号分隔的原始枚举（未映射）

