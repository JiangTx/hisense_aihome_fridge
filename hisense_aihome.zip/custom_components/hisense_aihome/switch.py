"""开关实体：除菌净化。

⚠️ 关于「智能 / 速冷 / 一键冰封」为什么不做成开关
------------------------------------------------------------------
云端的工作模式是**单值互斥枚举**（状态字段 workMode）：

    0 = 智能    3 = 速冷    7 = 一键冰封

也就是说任意时刻**只能是其中一种**，不存在「同时开速冷和智能」。
如果做成三个独立开关：
  1. 视觉上会误导用户以为可以同时开启；
  2. HA 设备页标题栏的「总开关」会同时对全部开关下发 turn_on，
     三条 SetModes 命令互相覆盖，最终落在最后一个上（表现为「点一下总开关
     就跳到速冷」）；
  3. 下发子开关命令（如 SetModes.QuickCooling）会让云端把 workMode
     置为非法值 "--"（实测），反而破坏状态。

因此三种模式统一由 select.py 的「模式」下拉实体表达，
本文件只保留真正独立的布尔量：除菌净化（clearSwitch）。
"""

from __future__ import annotations

from homeassistant.components.switch import SwitchEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import CATEGORY_FRIDGE, CMD_PREFIX
from .coordinator import HisenseCoordinator
from .entity import HisenseEntity


async def async_setup_entry(
    hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback
) -> None:
    coordinator: HisenseCoordinator = hass.data["hisense_aihome"][entry.entry_id]
    entities = []
    for device_id, dev in coordinator.devices.items():
        if dev.get("category_code") != CATEGORY_FRIDGE:
            continue
        entities.append(HisenseClearSwitch(coordinator, device_id))
        # 如需启用「静音模式」等其它真正独立的布尔开关，参考 MODE_SWITCHES
        # 的写法自行新增（注意：只有底层是独立布尔字段的才适合做 switch）。
    async_add_entities(entities)


class HisenseClearSwitch(HisenseEntity, SwitchEntity):
    """除菌净化（negative-ion 净化），底层是独立布尔字段 clearSwitch。"""

    _attr_name = "除菌净化"
    _attr_icon = "mdi:air-purifier"

    def __init__(self, coordinator, device_id) -> None:
        super().__init__(coordinator, device_id, "switch_clear")

    @property
    def is_on(self) -> bool:
        return self.state_of("clearSwitch", "0") == "1"

    async def async_turn_on(self, **kwargs) -> None:
        await self.coordinator.async_send_command(
            self._device_id, CMD_PREFIX + "ClearSwitch", {"clearSwitch": {"value": 1}}
        )

    async def async_turn_off(self, **kwargs) -> None:
        await self.coordinator.async_send_command(
            self._device_id, CMD_PREFIX + "ClearSwitch", {"clearSwitch": {"value": 0}}
        )
