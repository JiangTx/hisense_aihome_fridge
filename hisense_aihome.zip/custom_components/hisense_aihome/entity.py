"""实体基类：统一把一台家电的所有实体挂到同一个设备下。"""

from __future__ import annotations

from typing import Any

from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN
from .coordinator import HisenseCoordinator


class HisenseEntity(CoordinatorEntity[HisenseCoordinator]):
    """所有实体的公共基类。

    关键点：DeviceInfo 的 identifiers 只取决于 device_id，
    因此同一台家电的温度、模式、开关等实体在 HA 里会归到同一个设备卡片下
    （一次添加集成 → 一台冰箱 → 挂载全部实体）。
    """

    _attr_has_entity_name = True

    def __init__(self, coordinator: HisenseCoordinator, device_id: str, key: str) -> None:
        super().__init__(coordinator)
        self._device_id = device_id
        self._attr_unique_id = f"{device_id}_{key}"

    # ------------------------------------------------------------------ helpers
    @property
    def _device(self) -> dict[str, Any]:
        return self.coordinator.devices.get(self._device_id, {})

    @property
    def _states(self) -> dict[str, Any]:
        return self._device.get("states") or {}

    @property
    def _device_name(self) -> str:
        return self._device.get("device_name") or "海信设备"

    @property
    def _report(self) -> dict[str, Any]:
        """本月的「使用报告」（开门次数 / 时长 / 除菌次数等），可能为空。"""
        return self.coordinator.reports.get(self._device_id) or {}

    def state_of(self, key: str, default: str | None = None) -> str | None:
        val = self._states.get(key, default)
        return None if val is None else str(val)

    @property
    def available(self) -> bool:
        return super().available and bool(self._device) and self._device.get("online", True)

    @property
    def device_info(self) -> DeviceInfo:
        dev = self._device
        return DeviceInfo(
            identifiers={(DOMAIN, self._device_id)},
            name=dev.get("device_name") or "海信设备",
            manufacturer="海信 (Hisense)",
            model=dev.get("product_name") or dev.get("product_code") or None,
            suggested_area=dev.get("room_name") or None,
            configuration_url="https://iot-aihome.hismarttv.com",
        )
