"""海信爱家 冰箱 (Hisense AiHome Fridge) —— Home Assistant 自定义集成。

手动安装：把 custom_components/hisense_aihome 整个目录放入 HA 配置目录的
custom_components/ 下，重启 HA，然后在「设置 → 设备与服务 → 添加集成」里搜索
「海信爱家 冰箱」。无需 HACS。

目前仅适配冰箱品类（海信爱家云端 connector.device.type.fridge）。
"""

from __future__ import annotations

import logging

from homeassistant.config_entries import ConfigEntry
from homeassistant.const import Platform
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import ConfigEntryAuthFailed, ConfigEntryNotReady
from homeassistant.helpers import aiohttp_client

from .api import HisenseAiHomeClient, HisenseAuthError, HisenseConnectionError
from .const import CONF_ACCESS_TOKEN, CONF_CUSTOMER_ID, DOMAIN
from .coordinator import HisenseCoordinator

_LOGGER = logging.getLogger(__name__)

PLATFORMS: list[Platform] = [
    Platform.BINARY_SENSOR,
    Platform.NUMBER,
    Platform.SELECT,
    Platform.SENSOR,
    Platform.SWITCH,
]


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """按配置条目建立集成。"""
    session = aiohttp_client.async_get_clientsession(hass)
    client = HisenseAiHomeClient(session)
    coordinator = HisenseCoordinator(hass, entry, client)

    try:
        await coordinator.async_config_entry_first_refresh()
    except HisenseAuthError as err:
        raise ConfigEntryAuthFailed(str(err)) from err
    except HisenseConnectionError as err:
        raise ConfigEntryNotReady(str(err)) from err

    hass.data.setdefault(DOMAIN, {})[entry.entry_id] = coordinator

    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    entry.async_on_unload(entry.add_update_listener(_async_update_listener))
    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    unloaded = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unloaded:
        hass.data.get(DOMAIN, {}).pop(entry.entry_id, None)
    return unloaded


async def _async_update_listener(hass: HomeAssistant, entry: ConfigEntry) -> None:
    await hass.config_entries.async_reload(entry.entry_id)
